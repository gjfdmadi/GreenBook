$(function(){

	$(".title0").on("click",function(e){
		$(".content").not(".content0").removeClass("on")
		$(".contentbox .content0").toggleClass("on");
	});
	$(".title1").on("click",function(e){
		$(".content").not(".content1").removeClass("on")
		$(".contentbox .content1").toggleClass("on");
	});
	$(".title2").on("click",function(e){
		$(".content").not(".content2").removeClass("on")
		$(".contentbox .content2").toggleClass("on");
	});
	$(".title3").on("click",function(e){
		$(".content").not(".content3").removeClass("on")
		$(".contentbox .content3").toggleClass("on");
	});
	$(".title4").on("click",function(e){
		$(".content").not(".content4").removeClass("on")
		$(".contentbox .content4").toggleClass("on");
	});
	$(".title5").on("click",function(e){
		$(".content").not(".content5").removeClass("on")
		$(".contentbox .content5").toggleClass("on");
	});
	$(".title6").on("click",function(e){
		$(".content").not(".content6").removeClass("on");
		$(".contentbox .content6").toggleClass("on");
	});
	$(".title7").on("click",function(e){
		$(".content").not(".content7").removeClass("on");
		$(".contentbox .content7").toggleClass("on");
	});
	$(".title8").on("click",function(e){
		$(".content").not(".content8").removeClass("on");
		$(".contentbox .content8").toggleClass("on");
	});
	$(".title9").on("click",function(e){
		$(".content").not(".content9").removeClass("on");
		$(".contentbox .content9").toggleClass("on");
	});
});

